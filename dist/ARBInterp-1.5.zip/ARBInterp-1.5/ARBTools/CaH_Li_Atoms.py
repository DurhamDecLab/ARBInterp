from __future__ import division
import random as rand
import numpy as np

		
##############################LET'S GO#######################################


def randomDistLi(N):
	LiRange = np.zeros((int(N), 6))
	Limeanx = 5.9738395645874877e-05           # Centre of x-distribution
	Limeany = -1.7126995957046163e-06            # Centre of y-distribution    
	Limeanz = -0.014            # Centre of z-distribution
	Lisigmax = 0.001030277127820527        # Width of pulse in x-direction, standard deviation of Gaussian
	Lisigmay = 0.00098867528495059551         # Width of pulse in y-direction, standard deviation of Gaussian
	Lisigmaz = 0.0018162331565957071         # Width of pulse in z-direction, standard deviation of Gaussian
	Limeanvx = 0.010816788887282923
	Limeanvy = -0.14427035510682096
	Limeanvz = 11.2                 # Mean velocity in z-direction
	Lisigmavx = 3.9533180531571546
	Lisigmavy = 11.500639789302667
	Lisigmavz = 13.172235903700496 # Standard deviation of vz
	for q in range(LiRange.shape[0]):
		x = rand.gauss(Limeanx, Lisigmax)
		y = rand.gauss(Limeany, Lisigmay)
		z = rand.gauss(Limeanz, Lisigmaz)
		vx = rand.gauss(Limeanvx, Lisigmavx)
		vy = rand.gauss(Limeanvy, Lisigmavy)
		vz = rand.gauss(Limeanvz, Lisigmavz)
		LiRange[q] = np.array([[x,y,z,vx,vy,vz]])
	return LiRange
			
def randomDistCaH(N):
	CaHRange = np.zeros((int(N), 6))
	CaHmeanx = 0.00037365690105608396           # Centre of x-distribution
	CaHmeany = -2.0324399519104662e-05            # Centre of y-distribution    
	CaHmeanz = -0.014            # Centre of z-distribution
	CaHsigmax = 0.00096468384142168215         # Width of pulse in x-direction, standard deviation of Gaussian
	CaHsigmay = 0.0011231964800700316         # Width of pulse in y-direction, standard deviation of Gaussian
	CaHsigmaz = 0.0011127155704429798         # Width of pulse in z-direction, standard deviation of Gaussian
	CaHmeanvx = 0.1241314859770867
	CaHmeanvy = 0.11140826320000269
	CaHmeanvz = 11.2                 # Mean velocity in z-direction
	CaHsigmavx = 1.5045345737639904
	CaHsigmavy = 5.1052516912695571
	CaHsigmavz = 1.9995524039884696 # Standard deviation of vz
	for q in range(CaHRange.shape[0]):
		x = rand.gauss(CaHmeanx, CaHsigmax)
		y = rand.gauss(CaHmeany, CaHsigmay)
		z = rand.gauss(CaHmeanz, CaHsigmaz)
		vx = rand.gauss(CaHmeanvx, CaHsigmavx)
		vy = rand.gauss(CaHmeanvy, CaHsigmavy)
		vz = rand.gauss(CaHmeanvz, CaHsigmavz)
		CaHRange[q] = np.array([[x,y,z,vx,vy,vz]])
	return CaHRange
